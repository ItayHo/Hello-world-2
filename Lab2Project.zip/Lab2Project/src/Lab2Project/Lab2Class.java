package Lab2Project;

public class Lab2Class {
	
	int []arr;
	
	public Lab2Class(int arr[]) {
		this.arr = arr;
	}
	
	//The method is finding the number that is repeating itself, and send it to different class.
	public void FindNumThatRepeat() {
		for(int i=1;i<arr.length;i++) {
			for(int j=0;j<i;j++) {
				if(arr[i] == arr[j]) {
					PrintClass.Print(arr[i]);
					System.exit(0);
				}
			}
		}
	}
	
	public static void main(String[] args) {
		int []arr = new int[5];
		arr[0] = 3;
		arr[1] = 4;
		arr[2] = 3;
		arr[3] = 7;
		arr[4] = 5;
		
		new Lab2Class(arr).FindNumThatRepeat();
	}
}
