package Lab2Project;

public class PrintClass {
	
	public static void Print(int num) {
		System.out.println("The number " + num + " is repeating itself.");
	}

}
